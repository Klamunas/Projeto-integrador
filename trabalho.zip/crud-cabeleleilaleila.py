import os

os.system("pip install mysql-connector-python")

import mysql.connector 
import datetime

def conectarBD(host, usuario, senha, DB):
    connection = mysql.connector.connect( #Informando os dados para conexão com o BD
        host = host, #ip do servidor do BD
        user = usuario, #Usuário do MySQL 
        password = senha, #Senha do usuário do MySQL
        database = DB  #nome do DB criado
    ) #Define o banco de dados usado

    return connection

#INSERT
def insert_BD(conn, *dados):
    connection = conn #Recebe a conexão estabelecida com o banco
    cursor = connection.cursor() #Cursor para comunicação com o banco

    sql = "INSERT INTO CLIENTE(nome,rg,cpf,endereço,cidade,uf,telefone) VALUES (%s, %s, %s, %s,%s,%s,%s)"
    data = (dados[0], dados[1], dados[2], dados[3], dados[4], dados[5], dados[6])
    
    
    sql  = "INSERT INTO produto (nome, descricao, preco) VALUES (%s, %s, %s)"
    data = (dados[0], dados[1], dados[2])

    cursor.execute(sql, data) #Executa o comando SQL
    connection.commit() #Efetua as modificações

    clientid = cursor.lastrowid #Obtém o último ID cadastrado

    cursor.close() #Fecha o cursor
    connection.close() #Fecha a conexão com o BD


    


###READ
def read_BD(conn):
    connection = conn #Recebe a conexão estabelecida com o banco
    cursor = connection.cursor() #Cursor para comunicação com o banco

    sql = "SELECT * FROM cliente" #Realizando um select para mostrar todas as linhas e colunas da tabela

    sql = "SELECT * FROM produto WHERE id_produto = %s"
    data = (id,)

    cursor.execute(sql) #Executa o comando SQL
    results = cursor.fetchall() #Obtém todas as linhas no conjunto de resultados da consulta

    cursor.close() #fecha o cursor
    connection.close() #Fecha a conexão com o banco

    for result in results: #Ler os registros existentes com o select
        print(result) #imprime os registros existentes

#UPDATE

def update_BD(nome, telefone, id, endereço, conn):
    connection = conn #Recebe a conexão estabelecida com o banco
    cursor = connection.cursor() #Cursor para comunicação com o banco

    sql = "UPDATE Cliente SET nome = %s, telefone = %s, endereço = %s WHERE id = %s"
    data = (nome, 
            telefone,
            endereço,
            id
            )

    cursor.execute(sql, data) #Executa o comando SQL
    connection.commit()  #Efetua as modificações

    recordsaffected = cursor.rowcount #Obtém o número de linhas afetadas 

    cursor.close() #Fecha o cursor
    connection.close() #Fecha a conexão com o banco

    print(recordsaffected, " registros alterados")

#DELETE
def delete_BD(id,conn):
    connection = conn #Recebe a conexão estabelecida com o banco
    cursor = connection.cursor() #Cursor para comunicação com o banco

    sql = "DELETE FROM cliente WHERE id = %s"
    data = (id,)

    cursor.execute(sql, data) #Executa o coma ndo SQL
    connection.commit() #Efetua as modificações

    recordsaffected = cursor.rowcount #Obtém o número de linhas afetadas

    cursor.close() #Fecha o cursor
    connection.close() #Fecha a conexão com o banco

    print(recordsaffected, " registros excluídos")

import time
while(True):
    os.system("clear")
    print("::::: GERENCIADOR DE CADASTRO DE CLIENTES :::::")
    print("1 - CADASTRAR NOVO CLIENTE")
    print("2 - LISTAR OS CLIENTES CADASTRADOS")
    print("3 - ATUALIZAR CADASTRO DO CLIENTE")
    print("4 - REMOVER CLIENTE CADASTRADO")
    print("0 - Sair")
    opcao = int(input("Digite a opção desejada:"))
    if opcao == 0:
        break
    elif opcao == 1:
        nome = input("Digite o nome completo do cliente:")
        rg = input("Digite o RG:")
        cpf = input("Digite o CPF:")
        endereço = input("Digite o endereço:")
        cidade = input("Digite a cidade:")
        uf = input("Digite a sigla do estado (UF):")
        telefone = input("Digite o seu telefone para o contato:")
        connection = conectarBD("localhost", "root", "admin", "Projeto")
        insert_BD(nome,rg,cpf,endereço,cidade,uf,telefone,connection)
        time.sleep(3)
    elif opcao == 2:
        connection = conectarBD("localhost", "root", "admin", "Projeto")
        print("Os registros existentes na tabela são:")
        read_BD(connection)
        time.sleep(3)
    elif opcao == 3: 
        id = int(input("Digite o id do cliente no qual deseja atualizar:"))
        nome = input("Digite o novo nome do cliente:")
        telefone = int(input("Digite o seu novo telefone para o contato:"))
        endereço = input("Digite seu novo endereço:")
        connection = conectarBD("localhost", "root", "admin", "Projeto")
        update_BD(nome,telefone,id,connection)
        time.sleep(3)
    elif opcao == 4: 
        id = input("Digite o id do usuário no qual deseja deletar:")
        connection = conectarBD("localhost", "root", "admin", "Projeto")
        delete_BD(id,connection)
        time.sleep(3)
    else:
        print("Opção inválida!")
        time.sleep(3)