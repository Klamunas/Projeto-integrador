Create database Projeto;
use Projeto;

Create table Cliente(
id int auto_increment primary key,
nome varchar(100),
rg varchar(12),
cpf varchar(15),
endereço varchar(100),
cidade varchar(100),
UF varchar(3),
telefone varchar(15));

select * FROM Cliente;


Create table produto (
id_produto INT NOT NULL primary key auto_increment,
nome VARCHAR (100) NOT NULL,
preco varchar(10) NOT NULL);

SELECT * FROM produto;
