CREATE DATABASE db_registro;
USE db_registro;

CREATE TABLE cliente (
id_cliente INT NOT NULL primary key auto_increment,
nome VARCHAR (100) NOT NULL,
data_nasc DATE NOT NULL,
cpf VARCHAR (14) NOT NULL,
endereco VARCHAR (99) NOT NULL,
cep VARCHAR (9) NOT NULL,
telefone VARCHAR (15) NOT NULL,
email VARCHAR (99) NOT NULL
);

SELECT * FROM cliente;

CREATE TABLE produto (
id_produto INT NOT NULL primary key auto_increment,
nome VARCHAR (100) NOT NULL,
descricao VARCHAR (500) NOT NULL,
num_estoque varchar(6) NOT NULL,
preco varchar(10) NOT NULL
);

SELECT * FROM produto;