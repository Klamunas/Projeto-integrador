from PyQt5 import uic, QtWidgets
from PyQt5.QtCore import *
import sys
import os

os.system("pip install mysql-connector-python")

import mysql.connector

def conectarBD(host, usuario, senha, DB):
    connection   = mysql.connector.connect( #Informando os dados para conexão com o BD
        host     = host,        #ip do servidor do BD
        user     = usuario,     #Usuário do MySQL 
        password = senha,       #Senha do usuário do MySQL
        database = DB           #nome do DB criado
    ) #Define o banco de dados usado

    return connection

def insert_BD(tela, *dados):
    connection = conectarBD("localhost", "root", "admin", "db_registro")
    cursor     = connection.cursor()

    if telaCliente.txtNome.text() != "":
        sql  = "INSERT INTO cliente (nome, data_nasc, cpf, endereco, cep, telefone, email) VALUES (%s, %s, %s, %s, %s, %s, %s)"
        data = (dados[0], dados[1], dados[2], dados[3], dados[4], dados[5], dados[6])
    if telaProduto.txtNome.text() != "":
        sql  = "INSERT INTO produto (nome, descricao, num_estoque, preco) VALUES (%s, %s, %s, %s)"
        data = (dados[0], dados[1], dados[2], dados[3])

    cursor.execute(sql, data)
    connection.commit()

    userid = cursor.lastrowid

    cursor.close()
    connection.close()
    
    if tela == "cliente":
        telaCliente.txtID.setText("%s" % userid)
    else:        
        telaProduto.txtID.setText("%s" % userid)
    print("Foi cadastrado o novo registro de ID:", userid)
    del dados

def read_BD(id):
    connection = conectarBD("localhost", "root", "admin", "db_registro")
    cursor     = connection.cursor()

    if telaCliente.txtID.text() != "":
        sql = "SELECT * FROM cliente WHERE id_cliente = %s"
    if telaProduto.txtID.text() != "":
        sql = "SELECT * FROM produto WHERE id_produto = %s"
    data = (id,)

    cursor.execute(sql, data)
    results = cursor.fetchall()

    cursor.close()
    connection.close()

    if telaCliente.txtID.text() > "":
        for result in results:
            telaCliente.txtNome.setText(str(result[1]))
            telaCliente.txtDataNasc.setText(str(result[2]))
            telaCliente.txtCPF.setText(str(result[3]))
            telaCliente.txtEndereco.setText(str(result[4]))
            telaCliente.txtCEP.setText(str(result[5]))
            telaCliente.txtTelefone.setText(str(result[6]))
            telaCliente.txtEmail.setText(str(result[7]))
    if telaProduto.txtID.text() > "":
        for result in results:
            telaProduto.txtNome.setText(str(result[1]))
            telaProduto.txtDescricao.setText(str(result[2]))
            telaProduto.txtNumEstoque.setText(str(result[3]))
            telaProduto.txtPreco.setText(str(result[4]))


def update_BD(*dados):
    connection = conectarBD("localhost", "root", "admin", "db_registro")
    cursor     = connection.cursor()
    
    if telaCliente.txtNome.text() != "":
        sql = "UPDATE cliente SET nome = %s, data_nasc = %s, cpf = %s, endereco = %s, cep = %s, telefone = %s, email = %s WHERE id_cliente = %s"
        data = (dados[0], dados[1], dados[2], dados[3], dados[4], dados[5], dados[6], dados[7])
    if telaProduto.txtNome.text() != "":    
        sql = "UPDATE produto SET nome = %s, descricao = %s, num_estoque = %s, preco = %s WHERE id_produto = %s"
        data = (dados[0], dados[1], dados[2], dados[3], dados[4])

    
    cursor.execute(sql, data)
    connection.commit()

    recordsaffected = cursor.rowcount

    cursor.close()
    connection.close()

    del dados
    print(recordsaffected, " registros alterados")
    
def delete_BD(id):
    connection = conectarBD("localhost", "root", "admin", "db_registro")
    cursor     = connection.cursor()

    if telaCliente.txtID.text() != "":
        sql  = "DELETE FROM cliente WHERE id_cliente = %s"
    if telaProduto.txtID.text() != "":
        sql  = "DELETE FROM produto WHERE id_produto = %s"
    data = (id,)

    cursor.execute(sql, data)
    connection.commit()

    recordsaffected = cursor.rowcount

    cursor.close()
    connection.close()

    print(recordsaffected, " registros excluídos")


def inserir(tela):
    if telaCliente.txtNome.text() != "":
        nome      = telaCliente.txtNome.text()
        data_nasc = telaCliente.txtDataNasc.text()
        cpf       = telaCliente.txtCPF.text()
        endereco  = telaCliente.txtEndereco.text()
        cep       = telaCliente.txtCEP.text()
        telefone  = telaCliente.txtTelefone.text()
        email     = telaCliente.txtEmail.text()
        insert_BD(tela, nome, data_nasc, cpf, endereco, cep, telefone, email)
    if telaProduto.txtNome.text() != "":
        nome        = telaProduto.txtNome.text()
        descricao   = telaProduto.txtDescricao.text()
        num_estoque = telaProduto.txtNumEstoque.text()
        preco       = telaProduto.txtPreco.text()
        insert_BD(tela, nome, descricao, num_estoque, preco)

def limpar():
    if telaCliente.txtID.text() != "" or telaCliente.txtID.text() == "":
        telaCliente.txtNome.setText("")
        telaCliente.txtDataNasc.setText("")
        telaCliente.txtCPF.setText("")
        telaCliente.txtEndereco.setText("")
        telaCliente.txtCEP.setText("")
        telaCliente.txtTelefone.setText("")
        telaCliente.txtEmail.setText("")
    if telaProduto.txtID.text() != "" or telaProduto.txtID.text() == "":
        telaProduto.txtNome.setText("")
        telaProduto.txtDescricao.setText("")
        telaProduto.txtNumEstoque.setText("")
        telaProduto.txtPreco.setText("")

def consultar():
    if telaCliente.txtID.text() != "":
        id = telaCliente.txtID.text()
    if telaProduto.txtID.text() != "":
        id = telaProduto.txtID.text()
    read_BD(id)

def atualizar():
    if telaCliente.txtID.text() != "":
        id        = telaCliente.txtID.text()
        nome      = telaCliente.txtNome.text()
        data_nasc = telaCliente.txtDataNasc.text()
        cpf       = telaCliente.txtCPF.text()
        endereco  = telaCliente.txtEndereco.text()
        cep       = telaCliente.txtCEP.text()
        telefone  = telaCliente.txtTelefone.text()
        email     = telaCliente.txtEmail.text()
        update_BD(nome, data_nasc, cpf, endereco, cep, telefone, email, id)
    if telaProduto.txtID.text() != "":
        id          = telaProduto.txtID.text()
        nome        = telaProduto.txtNome.text()
        descricao   = telaProduto.txtDescricao.text()
        num_estoque = telaProduto.txtNumEstoque.text()
        preco       = telaProduto.txtPreco.text()
        update_BD(nome, descricao, num_estoque, preco, id)

def deletar():
    if telaCliente.txtID.text() != "":
        id = telaCliente.txtID.text()
    if telaProduto.txtID.text() != "":
        id = telaProduto.txtID.text()
    delete_BD(id)

def produto():
    telaCliente.hide()
    limpar()
    telaCliente.txtID.setText("")
    telaProduto.show()
    limpar()
    telaProduto.txtID.setText("")

def cliente():
    telaProduto.hide()
    limpar()
    telaProduto.txtID.setText("")
    telaCliente.show()
    limpar()
    telaCliente.txtID.setText("")

def primeiro(tela):
    connection = conectarBD("localhost", "root", "admin", "db_registro")
    cursor     = connection.cursor()

    if tela == "cliente":
        cursor.execute("SELECT * FROM cliente LIMIT 1")
        busca = cursor.fetchone()
        telaCliente.txtID.setText("%s" % busca[0])
    else:        
        cursor.execute("SELECT * FROM produto LIMIT 1")
        busca = cursor.fetchone()
        telaProduto.txtID.setText("%s" % busca[0])

    connection.close()
    consultar()

def anterior(tela):
    if tela == "cliente":
        if telaCliente.txtID.text() == "" or int(telaCliente.txtID.text()) == 1:
            primeiro(tela)
        else:
            busca = int(telaCliente.txtID.text()) - 1
            telaCliente.txtID.setText("%s" % busca)
    else:
        if telaProduto.txtID.text() == "" or int(telaProduto.txtID.text()) == 1:
            primeiro(tela)
        else:
            busca = int(telaProduto.txtID.text()) - 1
            telaProduto.txtID.setText("%s" % busca)
    consultar()
        
def proximo(tela):
    if tela == "cliente":
        if telaCliente.txtID.text() == "":
            primeiro(tela)
        else:
            busca = int(telaCliente.txtID.text()) + 1
            telaCliente.txtID.setText("%s" % busca)
    else:
        if telaProduto.txtID.text() == "":
            primeiro(tela)
        else:
            busca = int(telaProduto.txtID.text()) + 1
            telaProduto.txtID.setText("%s" % busca)
    consultar()
            
def ultimo(tela):
    connection = conectarBD("localhost", "root", "admin", "db_registro")
    cursor     = connection.cursor()

    if tela == "cliente":
        cursor.execute("SELECT * FROM cliente ORDER BY id_cliente DESC LIMIT 1")
        busca = cursor.fetchone()
        telaCliente.txtID.setText("%s" % busca[0])
    else:
        cursor.execute("SELECT * FROM produto ORDER BY id_produto DESC LIMIT 1")
        busca = cursor.fetchone()
        telaProduto.txtID.setText("%s" % busca[0])

    connection.close()
    consultar()
    

app = QtWidgets.QApplication(sys.argv)
telaCliente = uic.loadUi('cliente.ui')
telaProduto = uic.loadUi('produto.ui')
telaCliente.show()
telaCliente.btnCadastrar.clicked.connect(inserir)
telaCliente.btnLimpar.clicked.connect(limpar)
telaCliente.btnConsultar.clicked.connect(consultar)
telaCliente.btnAtualizar.clicked.connect(atualizar)
telaCliente.btnRemover.clicked.connect(deletar)
telaCliente.btnProduto.clicked.connect(produto)
telaCliente.btnPrimeiro.clicked.connect(lambda: primeiro("cliente"))
telaCliente.btnAnterior.clicked.connect(lambda: anterior("cliente"))
telaCliente.btnProximo.clicked.connect(lambda: proximo("cliente"))
telaCliente.btnUltimo.clicked.connect(lambda: ultimo("cliente"))

telaProduto.btnCadastrar.clicked.connect(inserir)
telaProduto.btnLimpar.clicked.connect(limpar)
telaProduto.btnConsultar.clicked.connect(consultar)
telaProduto.btnAtualizar.clicked.connect(atualizar)
telaProduto.btnRemover.clicked.connect(deletar)
telaProduto.btnCliente.clicked.connect(cliente)
telaProduto.btnPrimeiro.clicked.connect(primeiro)
telaProduto.btnAnterior.clicked.connect(anterior)
telaProduto.btnProximo.clicked.connect(proximo)
telaProduto.btnUltimo.clicked.connect(ultimo)
app.exec()
